// script.js

// Espera a que el DOM esté listo
document.addEventListener("DOMContentLoaded", () => {

  // 1. Validación de formulario de contacto
  const form = document.querySelector("form");
  if (form) {
    form.addEventListener("submit", (e) => {
      const nombre = document.getElementById("nombre")?.value.trim();
      const email = document.getElementById("email")?.value.trim();

      if (!nombre || !email) {
        alert("Por favor completa todos los campos.");
        e.preventDefault(); // Evita que se envíe
      }
    });
  }

  // 2. Botón de WhatsApp dinámico
  const whatsappBtn = document.querySelector("#Contacto a[href*='wa.me']");
  if (whatsappBtn) {
    whatsappBtn.addEventListener("click", () => {
      alert("Se abrirá WhatsApp para enviar tu mensaje.");
    });
  }

  // 3. Scroll suave en el menú
  document.querySelectorAll("nav ul li a").forEach(enlace => {
    enlace.addEventListener("click", function(e) {
      e.preventDefault();
      const seccion = document.querySelector(this.getAttribute("href"));
      if (seccion) {
        seccion.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // 4. Testimonios rotativos
  const testimonios = document.querySelectorAll("#Testimonios blockquote p");
  let index = 0;

  function mostrarTestimonio() {
    testimonios.forEach((t, i) => {
      t.style.display = i === index ? "block" : "none";
    });
    index = (index + 1) % testimonios.length;
  }

  if (testimonios.length > 0) {
    mostrarTestimonio();
    setInterval(mostrarTestimonio, 4000); // cambia cada 4 segundos
  }
});
